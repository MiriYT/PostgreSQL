--
-- PostgreSQL database dump
--

\restrict s0uCtKt41XAX5DxOn8YUgu6I4EUR2sx3tFsqcVg2jfIsuvBjsZs6iDCmm1eAGKq

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-12 09:45:06

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4971 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 220 (class 1259 OID 25458)
-- Name: doktorzy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doktorzy (
    iddoktora integer NOT NULL,
    imie character varying(100) NOT NULL,
    nazwisko character varying(255) NOT NULL,
    data_urodzenia date,
    mail character varying(255),
    idspecjalizacji integer NOT NULL
);


ALTER TABLE public.doktorzy OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 25512)
-- Name: grupa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grupa (
    idgrupa integer NOT NULL,
    idspecjalizacji integer NOT NULL,
    nazwa_grupy character varying(25) NOT NULL,
    data_rozpoczecia date
);


ALTER TABLE public.grupa OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25481)
-- Name: specjalizacje; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specjalizacje (
    idspecjalizacji integer NOT NULL,
    nazwa_specjalizacji character varying(50) NOT NULL,
    opis_specjalizacji character varying(255)
);


ALTER TABLE public.specjalizacje OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25567)
-- Name: specjalizacje_doktrow; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.specjalizacje_doktrow AS
 SELECT doktorzy.imie,
    doktorzy.nazwisko,
    specjalizacje.nazwa_specjalizacji
   FROM public.doktorzy,
    public.specjalizacje
  WHERE (specjalizacje.idspecjalizacji = doktorzy.idspecjalizacji);


ALTER VIEW public.specjalizacje_doktrow OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 25452)
-- Name: studenci; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studenci (
    idstudenta integer NOT NULL,
    idgrupa integer NOT NULL,
    imie character varying(100) NOT NULL,
    nazwisko character varying(255) NOT NULL,
    data_urodzenia date,
    mail character varying(255)
);


ALTER TABLE public.studenci OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 25563)
-- Name: specjalizacje_studentow; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.specjalizacje_studentow AS
 SELECT studenci.imie,
    studenci.nazwisko,
    specjalizacje.nazwa_specjalizacji
   FROM public.studenci,
    public.specjalizacje,
    public.grupa
  WHERE ((specjalizacje.idspecjalizacji = grupa.idspecjalizacji) AND (grupa.idgrupa = studenci.idgrupa));


ALTER VIEW public.specjalizacje_studentow OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 25467)
-- Name: zaliczenia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zaliczenia (
    iddoktora integer NOT NULL,
    idstudenta integer NOT NULL,
    ocena double precision,
    zaliczyl character varying(3) NOT NULL,
    CONSTRAINT zaliczenia_ocena_check CHECK (((ocena IS NULL) OR ((ocena >= (2.0)::double precision) AND (ocena <= (5.0)::double precision)))),
    CONSTRAINT zaliczenia_zaliczyl_check CHECK (((zaliczyl)::text = ANY ((ARRAY['Tak'::character varying, 'Nie'::character varying])::text[])))
);


ALTER TABLE public.zaliczenia OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25553)
-- Name: studenci_ktorzy_zaliczyli; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.studenci_ktorzy_zaliczyli AS
 SELECT studenci.imie,
    studenci.nazwisko,
    zaliczenia.zaliczyl
   FROM public.studenci,
    public.zaliczenia
  WHERE (((zaliczenia.zaliczyl)::text = 'Tak'::text) AND (studenci.idstudenta = zaliczenia.idstudenta));


ALTER VIEW public.studenci_ktorzy_zaliczyli OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 25472)
-- Name: zapisy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zapisy (
    idkandydata integer NOT NULL,
    imie character varying(25) NOT NULL,
    nazwisko character varying(25) NOT NULL,
    data_podania date,
    idspecjalizacji integer NOT NULL
);


ALTER TABLE public.zapisy OWNER TO postgres;

--
-- TOC entry 4961 (class 0 OID 25458)
-- Dependencies: 220
-- Data for Name: doktorzy; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (1, 'Adam', 'Kowalczyk', '1978-04-12', 'adam.kowalczyk@merito.pl', 1);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (2, 'Ewa', 'Nowak', '1982-09-03', 'ewa.nowak@merito.pl', 2);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (3, 'Tomasz', 'Mazur', '1975-01-22', 'tomasz.mazur@merito.pl', 3);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (4, 'Magdalena', 'Wiśniewska', '1980-06-15', 'magdalena.wisniewska@merito.pl', 4);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (5, 'Piotr', 'Zieliński', '1985-11-30', 'piotr.zielinski@merito.pl', 5);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (6, 'Marcin', 'Czarnecki', '1976-02-10', 'marcin.czarnecki@merito.pl', 1);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (7, 'Joanna', 'Szulc', '1983-08-21', 'joanna.szulc@merito.pl', 2);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (8, 'Krzysztof', 'Pawlak', '1979-12-05', 'krzysztof.pawlak@merito.pl', 5);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (9, 'Anna', 'Michalak', '1986-04-17', 'anna.michalak@merito.pl', 6);
INSERT INTO public.doktorzy (iddoktora, imie, nazwisko, data_urodzenia, mail, idspecjalizacji) VALUES (10, 'Robert', 'Błaszczyk', '1974-09-29', 'robert.blaszczyk@merito.pl', 7);


--
-- TOC entry 4965 (class 0 OID 25512)
-- Dependencies: 224
-- Data for Name: grupa; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.grupa (idgrupa, idspecjalizacji, nazwa_grupy, data_rozpoczecia) VALUES (1, 1, 'INF-CH-1', '2024-10-01');
INSERT INTO public.grupa (idgrupa, idspecjalizacji, nazwa_grupy, data_rozpoczecia) VALUES (2, 1, 'INF-CH-2', '2024-10-01');
INSERT INTO public.grupa (idgrupa, idspecjalizacji, nazwa_grupy, data_rozpoczecia) VALUES (3, 2, 'ZAR-CH-1', '2024-10-01');
INSERT INTO public.grupa (idgrupa, idspecjalizacji, nazwa_grupy, data_rozpoczecia) VALUES (4, 3, 'LOG-CH-1', '2024-10-01');
INSERT INTO public.grupa (idgrupa, idspecjalizacji, nazwa_grupy, data_rozpoczecia) VALUES (5, 5, 'CYB-CH-1', '2024-10-01');


--
-- TOC entry 4964 (class 0 OID 25481)
-- Dependencies: 223
-- Data for Name: specjalizacje; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (1, 'Informatyka', 'Programowanie i systemy informatyczne');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (2, 'Zarządzanie', 'Zarządzanie organizacją i projektami');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (3, 'Logistyka', 'Zarządzanie łańcuchem dostaw');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (4, 'Finanse i rachunkowość', 'Finanse przedsiębiorstw i rachunkowość');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (5, 'Cyberbezpieczeństwo', 'Bezpieczeństwo systemów i danych');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (6, 'Analityka danych', 'Analiza danych i business intelligence');
INSERT INTO public.specjalizacje (idspecjalizacji, nazwa_specjalizacji, opis_specjalizacji) VALUES (7, 'Administracja IT', 'Administracja systemami i infrastrukturą IT');


--
-- TOC entry 4960 (class 0 OID 25452)
-- Dependencies: 219
-- Data for Name: studenci; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (3, 3, 'Michał', 'Piotrowski', '2000-12-02', 'michal.piotrowski@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (4, 4, 'Agnieszka', 'Grabowska', '2001-05-27', 'agnieszka.grabowska@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (5, 5, 'Paweł', 'Lewandowski', '2002-09-14', 'pawel.lewandowski@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (6, 1, 'Sebastian', 'Urban', '2001-11-08', 'sebastian.urban@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (7, 1, 'Patrycja', 'Lis', '2002-01-19', 'patrycja.lis@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (8, 3, 'Damian', 'Rutkowski', '2000-06-30', 'damian.rutkowski@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (9, 4, 'Weronika', 'Adamska', '2001-03-12', 'weronika.adamska@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (10, 5, 'Bartosz', 'Kubiak', '2002-10-25', 'bartosz.kubiak@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (1, 1, 'Kamil', 'Dąbrowski', '2002-03-18', 'kamil.dabrowski@student.merito.pl');
INSERT INTO public.studenci (idstudenta, idgrupa, imie, nazwisko, data_urodzenia, mail) VALUES (2, 2, 'Natalia', 'Kaczmarek', '2001-07-09', 'natalia.kaczmarek@student.merito.pl');


--
-- TOC entry 4962 (class 0 OID 25467)
-- Dependencies: 221
-- Data for Name: zaliczenia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.zaliczenia (iddoktora, idstudenta, ocena, zaliczyl) VALUES (1, 1, 4.5, 'Tak');
INSERT INTO public.zaliczenia (iddoktora, idstudenta, ocena, zaliczyl) VALUES (1, 2, 3, 'Tak');
INSERT INTO public.zaliczenia (iddoktora, idstudenta, ocena, zaliczyl) VALUES (2, 3, 4, 'Tak');
INSERT INTO public.zaliczenia (iddoktora, idstudenta, ocena, zaliczyl) VALUES (3, 4, 2, 'Nie');
INSERT INTO public.zaliczenia (iddoktora, idstudenta, ocena, zaliczyl) VALUES (5, 5, NULL, 'Nie');


--
-- TOC entry 4963 (class 0 OID 25472)
-- Dependencies: 222
-- Data for Name: zapisy; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.zapisy (idkandydata, imie, nazwisko, data_podania, idspecjalizacji) VALUES (1, 'Monika', 'Król', '2024-07-01', 1);
INSERT INTO public.zapisy (idkandydata, imie, nazwisko, data_podania, idspecjalizacji) VALUES (2, 'Łukasz', 'Wójcik', '2024-07-02', 2);
INSERT INTO public.zapisy (idkandydata, imie, nazwisko, data_podania, idspecjalizacji) VALUES (3, 'Karolina', 'Kamińska', '2024-07-03', 3);
INSERT INTO public.zapisy (idkandydata, imie, nazwisko, data_podania, idspecjalizacji) VALUES (4, 'Rafał', 'Lewicki', '2024-07-04', 4);
INSERT INTO public.zapisy (idkandydata, imie, nazwisko, data_podania, idspecjalizacji) VALUES (5, 'Julia', 'Sikora', '2024-07-05', 5);


--
-- TOC entry 4793 (class 2606 OID 25551)
-- Name: doktorzy doktorzy_mail_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doktorzy
    ADD CONSTRAINT doktorzy_mail_unique UNIQUE (mail);


--
-- TOC entry 4795 (class 2606 OID 25463)
-- Name: doktorzy doktorzy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doktorzy
    ADD CONSTRAINT doktorzy_pkey PRIMARY KEY (iddoktora);


--
-- TOC entry 4803 (class 2606 OID 25517)
-- Name: grupa grupa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupa
    ADD CONSTRAINT grupa_pkey PRIMARY KEY (idgrupa);


--
-- TOC entry 4801 (class 2606 OID 25486)
-- Name: specjalizacje specjalizacje_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specjalizacje
    ADD CONSTRAINT specjalizacje_pkey PRIMARY KEY (idspecjalizacji);


--
-- TOC entry 4789 (class 2606 OID 25549)
-- Name: studenci studenci_mail_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studenci
    ADD CONSTRAINT studenci_mail_unique UNIQUE (mail);


--
-- TOC entry 4791 (class 2606 OID 25457)
-- Name: studenci studenci_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studenci
    ADD CONSTRAINT studenci_pkey PRIMARY KEY (idstudenta);


--
-- TOC entry 4797 (class 2606 OID 25531)
-- Name: zaliczenia zaliczenia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zaliczenia
    ADD CONSTRAINT zaliczenia_pkey PRIMARY KEY (iddoktora, idstudenta);


--
-- TOC entry 4799 (class 2606 OID 25477)
-- Name: zapisy zapisy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapisy
    ADD CONSTRAINT zapisy_pkey PRIMARY KEY (idkandydata);


--
-- TOC entry 4806 (class 2606 OID 25502)
-- Name: zaliczenia fk_doktorzy_zali; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zaliczenia
    ADD CONSTRAINT fk_doktorzy_zali FOREIGN KEY (iddoktora) REFERENCES public.doktorzy(iddoktora);


--
-- TOC entry 4809 (class 2606 OID 25523)
-- Name: grupa fk_specjalizacja_grupa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupa
    ADD CONSTRAINT fk_specjalizacja_grupa FOREIGN KEY (idspecjalizacji) REFERENCES public.specjalizacje(idspecjalizacji);


--
-- TOC entry 4805 (class 2606 OID 25487)
-- Name: doktorzy fk_specjalizacje_dok; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doktorzy
    ADD CONSTRAINT fk_specjalizacje_dok FOREIGN KEY (idspecjalizacji) REFERENCES public.specjalizacje(idspecjalizacji);


--
-- TOC entry 4808 (class 2606 OID 25497)
-- Name: zapisy fk_specjalizacje_zapi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapisy
    ADD CONSTRAINT fk_specjalizacje_zapi FOREIGN KEY (idspecjalizacji) REFERENCES public.specjalizacje(idspecjalizacji);


--
-- TOC entry 4804 (class 2606 OID 25518)
-- Name: studenci fk_studenci_grupa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studenci
    ADD CONSTRAINT fk_studenci_grupa FOREIGN KEY (idgrupa) REFERENCES public.grupa(idgrupa);


--
-- TOC entry 4807 (class 2606 OID 25507)
-- Name: zaliczenia fk_studenci_zali; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zaliczenia
    ADD CONSTRAINT fk_studenci_zali FOREIGN KEY (idstudenta) REFERENCES public.studenci(idstudenta);


--
-- TOC entry 4972 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE doktorzy; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.doktorzy TO "Student";
GRANT SELECT ON TABLE public.doktorzy TO "Doktor";


--
-- TOC entry 4973 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE grupa; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.grupa TO "Student";
GRANT SELECT ON TABLE public.grupa TO "Doktor";


--
-- TOC entry 4974 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE specjalizacje; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.specjalizacje TO PUBLIC;
GRANT SELECT ON TABLE public.specjalizacje TO "Student";
GRANT SELECT ON TABLE public.specjalizacje TO "Doktor";


--
-- TOC entry 4975 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE studenci; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.studenci TO "Student";
GRANT SELECT ON TABLE public.studenci TO "Doktor";


--
-- TOC entry 4976 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE zaliczenia; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.zaliczenia TO "Doktor";
GRANT SELECT ON TABLE public.zaliczenia TO "Student";


--
-- TOC entry 4977 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE zapisy; Type: ACL; Schema: public; Owner: postgres
--

GRANT INSERT ON TABLE public.zapisy TO PUBLIC;
GRANT SELECT ON TABLE public.zapisy TO "Doktor";


-- Completed on 2026-01-12 09:45:07

--
-- PostgreSQL database dump complete
--

\unrestrict s0uCtKt41XAX5DxOn8YUgu6I4EUR2sx3tFsqcVg2jfIsuvBjsZs6iDCmm1eAGKq

