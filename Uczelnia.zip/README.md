# **Baza Uczelnia**

Plik ukazuje bazę, która jest przykładem protego systemu uczelni, jest możliwość wpisania oceny przez doktorów jaki i sprawdzenie ich przez studentów, do tego jest możliwość wpisania się kandydatów.

Sama baza w głównym zamyśle ma pokazywać to co jest najważniejsze w prostym obsługiwaniu uczelni. Są utworzone relacje dzięki czemu wiemy który student należy do jakiej grupy a ta do jakiej specjalizacji.



Użytkownicy:
Doktor - Ma wgląd w oceny oraz je wpisuje
Student - Może spojrzeć w to czy zaliczył dany przedmiot czy nie



Tabele:

Doktorzy - Spis doktorów na uczelni;

Grupa - Spis grup do których należą studenci;
Specjalizacje - Spis specjalizacje które można przypisać studentom jak i doktorom;

Studenci - Spis studentów na uczelni;

Zaliczenia - Informacje czy student zdał;
Zapisy - Informacje o kandydatach;



