# Backup Bazy

Film ukazuje w jaki sposób można utworzyć backup bazy postgreSQL, sam backup jest tworzony na dwóch maszynach wirtualnych posiadających system operacyjny linux(Debian);

Sam backup bazy służy do zapewnienia bezpieczeństwa przypadku awarii serwera SQL, pokazane jest również że zapis danych wykonuje się co 24h, co powoduje że utracone dane mogą zostać szybko naprawione, 

pliki są kompresowane ze względu na miejsce na dyskach, niektóre bazy mogą ważyć w gigabajtach więc dzięki kompresji zaoszczędzamy miejsce.

Zrobienie backupu nie należy do najcięższych rzeczy jednak najistotniejszą rzeczą jest poprawne utworzenie basha.



W nagraniu zapomniałem o pokazaniu komendy "crontab -e", jednak jej zasada jest prosta na samym dole wpisujemy: "0 22 \* \* \* /home/administrator/Pulpit/backup\_sklep.sh > /home/administrator/Pulpit/Backup\_debug.log 2>\&1",

dzięki temu codziennie o 22:00 będzie uruchamiany skrypt "backup\_sklep.sh", a w przypadku błędu dostaniemy informacje do pliku "Backup\_debug.log".





