# **Baza danych dla sklepu informatycznego**

Tabela klienci która zbiera podstawowe informacje o klientach wraz z kontaktem(telefon);

Tabela produkty która ma informacje o produktach które firma oferuje;

Tabela recenzje która posiada oceny oraz komentarze klientów na temat produktów;

Tabela pracownicy zbiera informacje o pracownikach m.in ich specjalizacje, login;

Tabela serwis która pokazuje który pracownik naprawia dany przedmiot wraz z cenną brutto;

Tabela zamowienia na podstawie id pokazuje jaki produkt został zamówiony przez danego klienta;



Widok klienci\_ktorzy\_dali\_ocene\_5 pokazuje jacy klienci dali ocene =5;

Widok pracownik\_od\_komputerow pokazuje pracowników którzy zajmują się naprawą komputerów;

Widok slabe\_opinie pokazuje oceny klientów <=3;



Baza posiada trzech użytkowników: worker - Pracownik który może usuwać, tworzyc, edytować oraz kasować dane aczkolwiek zależy od wymagań tabeli;

client - większość tabel może przeglądać za wyjątkiem takich z danymi wrażliwymi(np: pracownicy) oraz ma możliwość wpisywania recenzji;

postgres - może wszystko, jest administratorem bazy;



Baza idealnie może wpasować się w sklep informatyczny, jest elastyczna poprzez prostotę, relacje oraz sens tabel.

Utworzenie strony HTML do której podepniemy możliwość logowania się oraz wprowadzania danych daje idealnie połączenie dla interesantów jak i samych pracowników do klarownego wprowadzania danych.

#### UPDATE

Została dodana strona w języku php która pokazuje przykładowe możliwości takiej bazy oraz jej przydatnośc do jakiegoś prostego sklepu informatycznego, można ją rozbudować dzięki przypisanym typom danych.

Strona nie posiada wybitnego css jednak celem było pokazanie poprawności składni php która to pobiera bądź przesyła dane z bazy Postgres.

Dla 100% że wszystko zadziała baze należy otworzyc w postgres(PgAdmin4) i nazwać "Sklep\_informatyczny".

