<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep Informatyczny</title>
    <link rel="shortcut icon" href="logo.png"></link>
</head>
<style>
    * {
        font-family: arial;
    } html, body{
        background-color: #E1D9D1;
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        position: absolute;
        flex-grow: 1;
        overflow: hidden;

    } header {
        background: linear-gradient(to right, cyan, lightblue, lightblue, blue);
        float: left;
        width: 100%;
        height: 10%;
        font-family: "Harlow Solid Italic", serif;
        font-style: italic;
    } footer {
        text-align: right;
        justify-content: space-between;
        background: linear-gradient(to left, cyan, lightblue, lightblue, blue);
        font-size: small;
        float: left;
        width: 100%;
        height: 15%; 
        margin-top: auto;
        bottom: 0;
        display: flex;
    }  #left {
        width: 20%;
        float: left;
        background-color: #E1D9D1;
        height: 75%;
    } #right {
        width: 78%;
        float: right;
        background-color: lightgray;
        height: calc(75% - 20px);
        overflow-y: auto;
        overflow-x: hidden;
    } #zbedny {
        width: 2%;
        background-color: lightgray;
        height: 75%;
        float: left;
    } #p {
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    } table {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
        width: 98%;
        
    }  table, td, tr {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
    }     
</style>    
<body>
    <header>
    <h1 style="text-align: center;">Strona o sklepie Informatycznym</h1>
</header>
<div id=left>
    <ul>
    <h4 style="text-align: left;">Kategorie:</h4>
    <li><a href="index.php">Strona główna</a></li>
    <li><a href="pracownicy.php">Pracownicy</a></li>
    <li><a href="produkty.php">Produkty</a></li>
    <li><a href="zamowienia.php">Zamówienia</a></li>
    <li><a href="recenzje.php">Recenzje</a></li>
</ul>
</div>
<div id=zbedny></div>
<div id=right>
<?php
$serwer = "localhost";
$user = "postgres";
$pass = "Admin123"; 
$dbname = "Sklep_informatyczny"; 

$idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");

echo "<h2 id=p>Wszystkie recenzje</h2>";

$zapytanie ="
SELECT k.imie, k.nazwisko, p.nazwa AS nazwa, r.ocena, r.komentarz FROM recenzje r JOIN klienci k ON r.idklienta = k.idklienta JOIN produkty p ON r.idproduktu = p.idproduktu ORDER BY k.idklienta DESC
";

$wynik = pg_query($idpolaczenia, $zapytanie);

echo "<table border='1' cellpadding='6' cellspacing='0'>
<tr>
    <th>Imię</th>
    <th>Nazwisko</th>
    <th>Produkt</th>
    <th>Ocena</th>
    <th>Komentarz</th>
</tr>";

while($i = pg_fetch_array($wynik)){
    echo "<tr>
        <td>{$i['imie']}</td>
        <td>{$i['nazwisko']}</td>
        <td>{$i['nazwa']}</td>
        <td>{$i['ocena']}</td>
        <td>{$i['komentarz']}</td>
    </tr>";
}

echo "</table>";

echo "<hr><h2 id=p>Dodaj recenzję</h2>";

@$imie = $_POST['tekst1'];
@$nazwisko = $_POST['tekst2'];
@$nazwa = $_POST['tekst3'];
@$ocena = $_POST['tekst4'];
@$komentarz = $_POST['tekst5'];

if($imie && $nazwisko && $nazwa && $ocena && $komentarz){
    $zapytanie_klient = "SELECT idklienta FROM klienci WHERE imie='$imie' AND nazwisko='$nazwisko' LIMIT 1";
    $wynik_klient = pg_query($idpolaczenia, $zapytanie_klient);
    $klient = pg_fetch_array($wynik_klient);

    $zapytanie_produkt = "SELECT idproduktu FROM produkty WHERE nazwa='$nazwa' LIMIT 1";
    $wynik_produkt = pg_query($idpolaczenia, $zapytanie_produkt);
    $produkt = pg_fetch_array($wynik_produkt);

    if (@!$klient || @!$produkt) {
        die("<p><b>Błąd:</b> Najpierw coś zamów żeby wpisać recenzje lub upewnij się czy podałeś poprawny produkt</p><br><a href=recenzje.php>Powrót</a>");
    }

    $idproduktu = $produkt['idproduktu'];
    $idklienta = $klient['idklienta'];

    $zapytanie_insert = "INSERT INTO recenzje (idklienta, idproduktu, ocena, komentarz) VALUES ($idklienta, $idproduktu, '$ocena', '$komentarz')";
    pg_query($idpolaczenia, $zapytanie_insert);

    echo "<p><b>Dziękujemy za twoją recenzje</b></p>";
}

pg_close($idpolaczenia);
?>

<form method="POST" action="recenzje.php">
    Podaj imię: <input type="text" name="tekst1">
    | Podaj nazwisko: <input type="text" name="tekst2">
    | Podaj nazwe produktu: <input type="text" name="tekst3" size="8">
    <label for="lista">| Ocena:</label>
<select name="tekst4">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
</select>
    | Komentarz: <input type="text" name="tekst5" size=30 value="Napisz recenzje">
    |    <input type="submit" value="Dodaj recenzję">
</form>

</div>
<footer id='stopa'>
        <img src="logo.png"></img>
        <?php
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie_ocena="select round(avg(ocena),1) as ocena from recenzje";
    $wynik_ocena = pg_query($idpolaczenia, $zapytanie_ocena);
    while($o = pg_fetch_array($wynik_ocena)){ 
        echo "<p id=p>Średnia Opini: ".$o['ocena']."</p>";
        }
    pg_close($idpolaczenia);
?>
    <div>
        <h4>Dane kontakowe</h4>
        <p><b>Adres: </b>Katowice 40-145 ul. Karłowicza 67/121</p>
        <p><b>Telefon: </b>123 456 789</p>
        <p><b>E-mail: </b><a href="mailto:sklep@informatyk.pl">KatoTech@informatyk.pl</a></p><br>
    </div>
</footer>
</body>
</html>