<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep Informatyczny</title>
    <link rel="shortcut icon" href="logo.png"></link>
</head>
<style>
    * {
        font-family: arial;
    } html, body{
        background-color: #E1D9D1;
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        position: absolute;
        flex-grow: 1;
        overflow: hidden;

    } header {
        background: linear-gradient(to right, cyan, lightblue, lightblue, blue);
        float: left;
        width: 100%;
        height: 10%;
        font-family: "Harlow Solid Italic", serif;
        font-style: italic;
    } footer {
        text-align: right;
        justify-content: space-between;
        background: linear-gradient(to left, cyan, lightblue, lightblue, blue);
        font-size: small;
        float: left;
        width: 100%;
        height: 15%; 
        margin-top: auto;
        bottom: 0;
        display: flex;
    }  #left {
        width: 20%;
        float: left;
        background-color: #E1D9D1;
        height: 75%;
    } #right {
        width: 78%;
        float: right;
        background-color: lightgray;
        height: calc(75% - 20px);
        overflow-y: auto;
        overflow-x: hidden;
    } #zbedny {
        width: 2%;
        background-color: lightgray;
        height: 75%;
        float: left;
    } #p {
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    } table {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
        width: 98%;
        
    }  table, td, tr {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
    }     
</style>    
<body>
    <header>
    <h1 style="text-align: center;">Strona o sklepie Informatycznym</h1>
</header>
<div id=left>
    <ul>
    <h4 style="text-align: left;">Kategorie:</h4>
    <li><a href="index.php">Strona główna</a></li>
    <li><a href="pracownicy.php">Pracownicy</a></li>
    <li><a href="produkty.php">Produkty</a></li>
    <li><a href="zamowienia.php">Zamówienia</a></li>
    <li><a href="recenzje.php">Recenzje</a></li>
</ul>
</div>
<div id=zbedny></div>
<div id=right>
<?php    
    $serwer = "localhost";
    $user = "postgres";
    $pass = "Admin123"; 
    $dbname = "Sklep_informatyczny"; 
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie = "select * from produkty"; 
    $wynik_zapytania = pg_query($idpolaczenia, $zapytanie); 
        echo "<p id=p>Produkty</p>";
        echo "<table>
        <tr>
            <td><b>Nazwa Produktu</b></td>
            <td><b>Rok Produkcji</b></td>
            <td><b>Cena</b></td>
            <td><b>Dostępność</b></td>             
        </tr>";
        while($i = pg_fetch_array($wynik_zapytania)){ 
        echo "<tr>
            <td>",$i['nazwa'],"</td>
            <td>",$i['rok_produkcji'],"</td>
            <td>",$i['cena'],"</td>
            <td>",$i['dostepnosc'],"</td>             
        </tr>";} 
    echo "</table>"; 
    echo "<hr>"; 
    echo "<h2 id=p>Wyszukaj produkt: </h2>"; 
    @$filtr = $_POST['tekst1'];
    @$dane = $_POST['tekst2'];

if ($filtr && $dane) {
    $dozwolone = ["nazwa", "rok_produkcji", "cena", "dostepnosc"];
    $zapytanie_produkt = "SELECT * FROM produkty WHERE $filtr ILIKE '%$dane%';";
if ($filtr === "dostepnosc") {
    $zapytanie_produkt = "SELECT * FROM produkty WHERE dostepnosc ILIKE '$dane';";
} else {
    $zapytanie_produkt = "SELECT * FROM produkty WHERE $filtr ILIKE '%$dane%';";
}

    $wynik_produkt = pg_query($idpolaczenia, $zapytanie_produkt);
    if (!$wynik_produkt || pg_num_rows($wynik_produkt) == 0) {
        die("<p>Brak lub błąd danych</p><br><a href=produkty.php>Powrót</a>");
    }
    echo "<table id=pracownicy>
            <tr>
                <td><b>Nazwa Produktu</b></td>
                <td><b>Rok Produkcji</b></td>
                <td><b>Cena</b></td>
                <td><b>Dostępność</b></td>
            </tr>";
    while($i = pg_fetch_array($wynik_produkt)){ 
        echo "<tr>
                <td>{$i['nazwa']}</td>
                <td>{$i['rok_produkcji']}</td>
                <td>{$i['cena']}</td>
                <td>{$i['dostepnosc']}</td>
            </tr>";
    }
    echo "</table>";
}
        pg_close($idpolaczenia); 
?>
<br>
    <form method="POST" action="produkty.php">
    Co chcesz wyszukać:    <select name="tekst1">
  <option value="nazwa">Nazwa Produktu</option>
  <option value="rok_produkcji">Rok Produkcji</option>
  <option value="cena">Cena</option>
  <option value="dostepnosc">Dostępność</option>
</select>
    | Dane: <input type="text" name="tekst2" required>
    | <input type="submit" value="Wyszukaj">
</form>  
</div>
<footer id='stopa'>
        <img src="logo.png"></img>
        <?php
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie_ocena="select round(avg(ocena),1) as ocena from recenzje";
    $wynik_ocena = pg_query($idpolaczenia, $zapytanie_ocena);
    while($o = pg_fetch_array($wynik_ocena)){ 
        echo "<p id=p>Średnia Opini: ".$o['ocena']."</p>";
        }
    pg_close($idpolaczenia);
?>
    <div>
        <h4>Dane kontakowe</h4>
        <p><b>Adres: </b>Katowice 40-145 ul. Karłowicza 67/121</p>
        <p><b>Telefon: </b>123 456 789</p>
        <p><b>E-mail: </b><a href="mailto:sklep@informatyk.pl">KatoTech@informatyk.pl</a></p><br>
    </div>
</footer>
</body>
</html>